<?php

namespace ism\controllers;
use ism\lib\Role;
use ism\lib\Request;
use ism\lib\Session;
use ism\lib\Response;
use ism\models\UserModel;
use ism\lib\AbstractController;
use ism\lib\AbstractModel;
use ism\lib\PasswordEncoder;
use ism\models\CoursModel;

/**
 * Undocumented class
 */
class CoursController extends AbstractController{
    private AbstractModel $model;

    public function __construct(){
        parent::__construct();
        $this->model= new CoursModel;
    }

    public function listCourByProfesseur(){
        //$data= $this->model->;
    }

    public function listCourByClass(){
        
    }
}

?>