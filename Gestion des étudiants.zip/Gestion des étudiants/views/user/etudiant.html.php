<?php 

use ism\lib\Session;
?>
  <img src="..." class="img-thumbnail" alt="...">
  <div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
      Dropdown button
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
      <li><a class="dropdown-item" href="#">Action</a></li>
      <li><a class="dropdown-item" href="login.html.php">Lister les cours</a></li>
      <li><a class="dropdown-item" href="etudiant3.html.php">Lister les absences</a></li>
    </ul>
  </div>