<?php
//Chargement statique 
require_once(ROOT_CONFIG."helper.php");

?>